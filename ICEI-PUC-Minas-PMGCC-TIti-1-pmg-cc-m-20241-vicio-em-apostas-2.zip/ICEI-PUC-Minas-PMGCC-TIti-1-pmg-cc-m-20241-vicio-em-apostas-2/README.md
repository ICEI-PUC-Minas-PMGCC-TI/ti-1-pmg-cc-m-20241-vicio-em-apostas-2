# Projeto FVA

O projeto fva tem como objetivo reduzir o vício em apostas utilizando da conscientização e do controle financeiro para gradualmente diminuir o vício.


## Alunos integrantes da equipe

* Rafael Nascimento Jardim
* Mateus Morcatti Oliveira
* Rafael Souza Bandeira 
* Vinicius Guimaraes Ferreira
* Gabriel Fontes

## Professores responsáveis

* Luciana Mara Freitas Diniz
* Pedro Henrinque Ramos Costa

## Instruções de utilização

Assim que a primeira versão do sistema estiver disponível, deverá complementar com as instruções de utilização. Descreva como instalar eventuais dependências e como executar a aplicação.
