Diário de Emoções
Bem-vindo ao Diário de Emoções! Este projeto é uma aplicação web simples desenvolvida para ajudar pessoas a registrarem seus sentimentos e pensamentos relacionados ao vício em apostas online.

Instruções de Uso
Siga as etapas abaixo para configurar e executar o projeto em sua máquina:

Pré-Requisitos
Certifique-se de ter o Node.js instalado em seu sistema. 

Instalação
Baixe ou clone este repositório em sua máquina.

Navegue até o diretório diario-emocoes no terminal.
cd caminho/para/diario-emocoes


Instale as dependências do projeto utilizando o npm (Node Package Manager).
npm install

Execução do Projeto

Após a conclusão da instalação das dependências, inicie o servidor Node.js executando o seguinte comando:

node server.js

Abra um navegador da web e acesse o seguinte URL:

http://localhost:3000

Você agora pode utilizar o Diário de Emoções para adicionar, editar e excluir entradas relacionadas ao vício em apostas online. Sinta-se à vontade para expressar seus sentimentos e pensamentos de forma privada e segura.


Tecnologias Utilizadas
Node.js
Express.js
HTML
CSS
JavaScript