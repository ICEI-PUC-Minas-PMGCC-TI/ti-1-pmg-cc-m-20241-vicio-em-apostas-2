const express = require('express');
const fs = require('fs');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();
const PORT = 3000;
const dataFilePath = path.join(__dirname, 'data', 'diario.json');

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

const readData = () => {
    if (!fs.existsSync(dataFilePath)) {
        return [];
    }
    const jsonData = fs.readFileSync(dataFilePath);
    return JSON.parse(jsonData);
};

const writeData = (data) => {
    fs.writeFileSync(dataFilePath, JSON.stringify(data, null, 2));
};

app.post('/adicionar-entrada', (req, res) => {
    let data = readData();
    const newEntry = { id: Date.now(), ...req.body };
    data.push(newEntry);
    writeData(data);
    res.json({ success: true });
});

app.put('/editar-entrada/:id', (req, res) => {
    let data = readData();
    const index = data.findIndex(entry => entry.id == req.params.id);
    if (index !== -1) {
        data[index] = { id: req.params.id, ...req.body };
        writeData(data);
        res.json({ success: true });
    } else {
        res.json({ success: false });
    }
});

app.delete('/excluir-entrada/:id', (req, res) => {
    let data = readData();
    data = data.filter(entry => entry.id != req.params.id);
    writeData(data);
    res.json({ success: true });
});

app.get('/entradas', (req, res) => {
    const data = readData();
    res.json(data);
});

app.get('/entrada/:id', (req, res) => {
    const data = readData();
    const entry = data.find(entry => entry.id == req.params.id);
    res.json(entry || {});
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
