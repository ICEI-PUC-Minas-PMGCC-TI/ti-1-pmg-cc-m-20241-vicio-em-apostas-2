document.getElementById('diarioForm').addEventListener('submit', function (e) {
    e.preventDefault();

    let entryId = document.getElementById('entryId').value;
    let data = document.getElementById('data').value;
    let emocoes = document.getElementById('emocoes').value;
    let pensamentos = document.getElementById('pensamentos').value;

    let entrada = { data, emocoes, pensamentos };

    if (entryId) {
        // Editar entrada
        fetch(`/editar-entrada/${entryId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(entrada)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('diarioForm').reset();
                carregarEntradas();
            } else {
                alert('Erro ao editar entrada');
            }
        });
    } else {
        // Adicionar nova entrada
        fetch('/adicionar-entrada', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(entrada)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('diarioForm').reset();
                carregarEntradas();
            } else {
                alert('Erro ao adicionar entrada');
            }
        });
    }
});

function carregarEntradas() {
    fetch('/entradas')
    .then(response => response.json())
    .then(data => {
        let entradasDiv = document.getElementById('entradas');
        entradasDiv.innerHTML = '';
        data.forEach(entrada => {
            let div = document.createElement('div');
            div.className = 'entrada';
            div.innerHTML = `<strong>Data:</strong> ${entrada.data}<br>
                             <strong>Emoções:</strong> ${entrada.emocoes}<br>
                             <strong>Pensamentos:</strong> ${entrada.pensamentos}<br>
                             <button onclick="editarEntrada(${entrada.id})">Editar</button>
                             <button onclick="excluirEntrada(${entrada.id})">Excluir</button>`;
            entradasDiv.appendChild(div);
        });
    });
}

function excluirEntrada(id) {
    fetch(`/excluir-entrada/${id}`, { method: 'DELETE' })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            carregarEntradas();
        } else {
            alert('Erro ao excluir entrada');
        }
    });
}

function editarEntrada(id) {
    fetch(`/entrada/${id}`)
    .then(response => response.json())
    .then(data => {
        document.getElementById('entryId').value = data.id;
        document.getElementById('data').value = data.data;
        document.getElementById('emocoes').value = data.emocoes;
        document.getElementById('pensamentos').value = data.pensamentos;
    });
}

window.onload = carregarEntradas;
